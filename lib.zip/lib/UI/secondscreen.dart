import 'dart:math';

import 'package:flutter/material.dart';

class SecondScreen extends StatefulWidget {

  dynamic number;
  SecondScreen({this.number});

  @override
  _SecondScreenState createState() => _SecondScreenState(countNumber: number);
}

class _SecondScreenState extends State<SecondScreen> {

  dynamic countNumber;
  _SecondScreenState({this.countNumber});

  List colors = [Colors.blue, Colors.red, Colors.grey];
  Random random = new Random();

  int index = 0;
  int selectedIndex = 0;

  /*void changeIndex() {
    print(index);
    setState(() => index = random.nextInt(3));

  }*/

  void changeIndex(index) {
    print(index);
    setState(() {
      if(index != selectedIndex){

      }
      /*if(index != index2){
        index2 = random.nextInt(3);
      }*/
      //index = random.nextInt(3);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Second Screen'),backgroundColor: Colors.grey,),
      body: _home(),
    );
  }

  Widget _home(){
    return Container(
      child: Center(
        child: Column(
          children: _buildList(),
        )
      ),
    );
  }

  List<Widget> _buildList() {
    List<Widget> listItems = List();

    for(var i=0; i<int.parse(countNumber); i++)
      listItems.add(
        RaisedButton(
          shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(30.0),
          ),
          onPressed: () {
            /*if(index == selectedIndex){
              print('1');

            } else if(index < selectedIndex){
              index = selectedIndex;
              print('->');
            } else if (index > selectedIndex){
              index = selectedIndex;
              print('<-');
            }*/

            index = i;
            changeIndex(index);
          },
            //=> changeIndex()
          child: Text('${i+1}'),
          color: (index == i) ? colors[index] : Colors.white,
        ),
      );

    listItems.add(SizedBox(
      height: 15,
    ));
    return listItems;
  }


}
